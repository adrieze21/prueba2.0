gdjs.New_32sceneCode = {};
gdjs.New_32sceneCode.GDPlayerObjects1_1final = [];

gdjs.New_32sceneCode.forEachCount0_5 = 0;

gdjs.New_32sceneCode.forEachCount1_5 = 0;

gdjs.New_32sceneCode.forEachIndex5 = 0;

gdjs.New_32sceneCode.forEachObjects5 = [];

gdjs.New_32sceneCode.forEachTotalCount5 = 0;



gdjs.New_32sceneCode.GDPlayerObjects1= [];
gdjs.New_32sceneCode.GDPlayerObjects2= [];
gdjs.New_32sceneCode.GDPlayerObjects3= [];
gdjs.New_32sceneCode.GDPlayerObjects4= [];
gdjs.New_32sceneCode.GDPlayerObjects5= [];
gdjs.New_32sceneCode.GDPlatformObjects1= [];
gdjs.New_32sceneCode.GDPlatformObjects2= [];
gdjs.New_32sceneCode.GDPlatformObjects3= [];
gdjs.New_32sceneCode.GDPlatformObjects4= [];
gdjs.New_32sceneCode.GDPlatformObjects5= [];
gdjs.New_32sceneCode.GDJumpthruObjects1= [];
gdjs.New_32sceneCode.GDJumpthruObjects2= [];
gdjs.New_32sceneCode.GDJumpthruObjects3= [];
gdjs.New_32sceneCode.GDJumpthruObjects4= [];
gdjs.New_32sceneCode.GDJumpthruObjects5= [];
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects1= [];
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects2= [];
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects3= [];
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects4= [];
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects5= [];
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects1= [];
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects2= [];
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects3= [];
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects4= [];
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects5= [];
gdjs.New_32sceneCode.GDMovingPlatformObjects1= [];
gdjs.New_32sceneCode.GDMovingPlatformObjects2= [];
gdjs.New_32sceneCode.GDMovingPlatformObjects3= [];
gdjs.New_32sceneCode.GDMovingPlatformObjects4= [];
gdjs.New_32sceneCode.GDMovingPlatformObjects5= [];
gdjs.New_32sceneCode.GDGoLeftObjects1= [];
gdjs.New_32sceneCode.GDGoLeftObjects2= [];
gdjs.New_32sceneCode.GDGoLeftObjects3= [];
gdjs.New_32sceneCode.GDGoLeftObjects4= [];
gdjs.New_32sceneCode.GDGoLeftObjects5= [];
gdjs.New_32sceneCode.GDGoRightObjects1= [];
gdjs.New_32sceneCode.GDGoRightObjects2= [];
gdjs.New_32sceneCode.GDGoRightObjects3= [];
gdjs.New_32sceneCode.GDGoRightObjects4= [];
gdjs.New_32sceneCode.GDGoRightObjects5= [];
gdjs.New_32sceneCode.GDLadderObjects1= [];
gdjs.New_32sceneCode.GDLadderObjects2= [];
gdjs.New_32sceneCode.GDLadderObjects3= [];
gdjs.New_32sceneCode.GDLadderObjects4= [];
gdjs.New_32sceneCode.GDLadderObjects5= [];
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1= [];
gdjs.New_32sceneCode.GDPlayerHitBoxObjects2= [];
gdjs.New_32sceneCode.GDPlayerHitBoxObjects3= [];
gdjs.New_32sceneCode.GDPlayerHitBoxObjects4= [];
gdjs.New_32sceneCode.GDPlayerHitBoxObjects5= [];
gdjs.New_32sceneCode.GDSlimeWalkObjects1= [];
gdjs.New_32sceneCode.GDSlimeWalkObjects2= [];
gdjs.New_32sceneCode.GDSlimeWalkObjects3= [];
gdjs.New_32sceneCode.GDSlimeWalkObjects4= [];
gdjs.New_32sceneCode.GDSlimeWalkObjects5= [];
gdjs.New_32sceneCode.GDFlyObjects1= [];
gdjs.New_32sceneCode.GDFlyObjects2= [];
gdjs.New_32sceneCode.GDFlyObjects3= [];
gdjs.New_32sceneCode.GDFlyObjects4= [];
gdjs.New_32sceneCode.GDFlyObjects5= [];
gdjs.New_32sceneCode.GDCloudObjects1= [];
gdjs.New_32sceneCode.GDCloudObjects2= [];
gdjs.New_32sceneCode.GDCloudObjects3= [];
gdjs.New_32sceneCode.GDCloudObjects4= [];
gdjs.New_32sceneCode.GDCloudObjects5= [];
gdjs.New_32sceneCode.GDBackgroundObjectsObjects1= [];
gdjs.New_32sceneCode.GDBackgroundObjectsObjects2= [];
gdjs.New_32sceneCode.GDBackgroundObjectsObjects3= [];
gdjs.New_32sceneCode.GDBackgroundObjectsObjects4= [];
gdjs.New_32sceneCode.GDBackgroundObjectsObjects5= [];
gdjs.New_32sceneCode.GDScoreObjects1= [];
gdjs.New_32sceneCode.GDScoreObjects2= [];
gdjs.New_32sceneCode.GDScoreObjects3= [];
gdjs.New_32sceneCode.GDScoreObjects4= [];
gdjs.New_32sceneCode.GDScoreObjects5= [];
gdjs.New_32sceneCode.GDCoinObjects1= [];
gdjs.New_32sceneCode.GDCoinObjects2= [];
gdjs.New_32sceneCode.GDCoinObjects3= [];
gdjs.New_32sceneCode.GDCoinObjects4= [];
gdjs.New_32sceneCode.GDCoinObjects5= [];
gdjs.New_32sceneCode.GDCoinIconObjects1= [];
gdjs.New_32sceneCode.GDCoinIconObjects2= [];
gdjs.New_32sceneCode.GDCoinIconObjects3= [];
gdjs.New_32sceneCode.GDCoinIconObjects4= [];
gdjs.New_32sceneCode.GDCoinIconObjects5= [];
gdjs.New_32sceneCode.GDLeftButtonObjects1= [];
gdjs.New_32sceneCode.GDLeftButtonObjects2= [];
gdjs.New_32sceneCode.GDLeftButtonObjects3= [];
gdjs.New_32sceneCode.GDLeftButtonObjects4= [];
gdjs.New_32sceneCode.GDLeftButtonObjects5= [];
gdjs.New_32sceneCode.GDRightButtonObjects1= [];
gdjs.New_32sceneCode.GDRightButtonObjects2= [];
gdjs.New_32sceneCode.GDRightButtonObjects3= [];
gdjs.New_32sceneCode.GDRightButtonObjects4= [];
gdjs.New_32sceneCode.GDRightButtonObjects5= [];
gdjs.New_32sceneCode.GDJumpButtonObjects1= [];
gdjs.New_32sceneCode.GDJumpButtonObjects2= [];
gdjs.New_32sceneCode.GDJumpButtonObjects3= [];
gdjs.New_32sceneCode.GDJumpButtonObjects4= [];
gdjs.New_32sceneCode.GDJumpButtonObjects5= [];
gdjs.New_32sceneCode.GDArrowButtonsBgObjects1= [];
gdjs.New_32sceneCode.GDArrowButtonsBgObjects2= [];
gdjs.New_32sceneCode.GDArrowButtonsBgObjects3= [];
gdjs.New_32sceneCode.GDArrowButtonsBgObjects4= [];
gdjs.New_32sceneCode.GDArrowButtonsBgObjects5= [];

gdjs.New_32sceneCode.conditionTrue_0 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_0 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_0 = {val:false};
gdjs.New_32sceneCode.conditionTrue_1 = {val:false};
gdjs.New_32sceneCode.condition0IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition1IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition2IsTrue_1 = {val:false};
gdjs.New_32sceneCode.condition3IsTrue_1 = {val:false};

gdjs.New_32sceneCode.func = function(runtimeScene, context) {
context.startNewFrame();
gdjs.New_32sceneCode.GDPlayerObjects1.length = 0;
gdjs.New_32sceneCode.GDPlayerObjects2.length = 0;
gdjs.New_32sceneCode.GDPlayerObjects3.length = 0;
gdjs.New_32sceneCode.GDPlayerObjects4.length = 0;
gdjs.New_32sceneCode.GDPlayerObjects5.length = 0;
gdjs.New_32sceneCode.GDPlatformObjects1.length = 0;
gdjs.New_32sceneCode.GDPlatformObjects2.length = 0;
gdjs.New_32sceneCode.GDPlatformObjects3.length = 0;
gdjs.New_32sceneCode.GDPlatformObjects4.length = 0;
gdjs.New_32sceneCode.GDPlatformObjects5.length = 0;
gdjs.New_32sceneCode.GDJumpthruObjects1.length = 0;
gdjs.New_32sceneCode.GDJumpthruObjects2.length = 0;
gdjs.New_32sceneCode.GDJumpthruObjects3.length = 0;
gdjs.New_32sceneCode.GDJumpthruObjects4.length = 0;
gdjs.New_32sceneCode.GDJumpthruObjects5.length = 0;
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects1.length = 0;
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects2.length = 0;
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects3.length = 0;
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects4.length = 0;
gdjs.New_32sceneCode.GDTiledGrassPlatformObjects5.length = 0;
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects1.length = 0;
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects2.length = 0;
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects3.length = 0;
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects4.length = 0;
gdjs.New_32sceneCode.GDTiledCastlePlatformObjects5.length = 0;
gdjs.New_32sceneCode.GDMovingPlatformObjects1.length = 0;
gdjs.New_32sceneCode.GDMovingPlatformObjects2.length = 0;
gdjs.New_32sceneCode.GDMovingPlatformObjects3.length = 0;
gdjs.New_32sceneCode.GDMovingPlatformObjects4.length = 0;
gdjs.New_32sceneCode.GDMovingPlatformObjects5.length = 0;
gdjs.New_32sceneCode.GDGoLeftObjects1.length = 0;
gdjs.New_32sceneCode.GDGoLeftObjects2.length = 0;
gdjs.New_32sceneCode.GDGoLeftObjects3.length = 0;
gdjs.New_32sceneCode.GDGoLeftObjects4.length = 0;
gdjs.New_32sceneCode.GDGoLeftObjects5.length = 0;
gdjs.New_32sceneCode.GDGoRightObjects1.length = 0;
gdjs.New_32sceneCode.GDGoRightObjects2.length = 0;
gdjs.New_32sceneCode.GDGoRightObjects3.length = 0;
gdjs.New_32sceneCode.GDGoRightObjects4.length = 0;
gdjs.New_32sceneCode.GDGoRightObjects5.length = 0;
gdjs.New_32sceneCode.GDLadderObjects1.length = 0;
gdjs.New_32sceneCode.GDLadderObjects2.length = 0;
gdjs.New_32sceneCode.GDLadderObjects3.length = 0;
gdjs.New_32sceneCode.GDLadderObjects4.length = 0;
gdjs.New_32sceneCode.GDLadderObjects5.length = 0;
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length = 0;
gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.length = 0;
gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.length = 0;
gdjs.New_32sceneCode.GDPlayerHitBoxObjects4.length = 0;
gdjs.New_32sceneCode.GDPlayerHitBoxObjects5.length = 0;
gdjs.New_32sceneCode.GDSlimeWalkObjects1.length = 0;
gdjs.New_32sceneCode.GDSlimeWalkObjects2.length = 0;
gdjs.New_32sceneCode.GDSlimeWalkObjects3.length = 0;
gdjs.New_32sceneCode.GDSlimeWalkObjects4.length = 0;
gdjs.New_32sceneCode.GDSlimeWalkObjects5.length = 0;
gdjs.New_32sceneCode.GDFlyObjects1.length = 0;
gdjs.New_32sceneCode.GDFlyObjects2.length = 0;
gdjs.New_32sceneCode.GDFlyObjects3.length = 0;
gdjs.New_32sceneCode.GDFlyObjects4.length = 0;
gdjs.New_32sceneCode.GDFlyObjects5.length = 0;
gdjs.New_32sceneCode.GDCloudObjects1.length = 0;
gdjs.New_32sceneCode.GDCloudObjects2.length = 0;
gdjs.New_32sceneCode.GDCloudObjects3.length = 0;
gdjs.New_32sceneCode.GDCloudObjects4.length = 0;
gdjs.New_32sceneCode.GDCloudObjects5.length = 0;
gdjs.New_32sceneCode.GDBackgroundObjectsObjects1.length = 0;
gdjs.New_32sceneCode.GDBackgroundObjectsObjects2.length = 0;
gdjs.New_32sceneCode.GDBackgroundObjectsObjects3.length = 0;
gdjs.New_32sceneCode.GDBackgroundObjectsObjects4.length = 0;
gdjs.New_32sceneCode.GDBackgroundObjectsObjects5.length = 0;
gdjs.New_32sceneCode.GDScoreObjects1.length = 0;
gdjs.New_32sceneCode.GDScoreObjects2.length = 0;
gdjs.New_32sceneCode.GDScoreObjects3.length = 0;
gdjs.New_32sceneCode.GDScoreObjects4.length = 0;
gdjs.New_32sceneCode.GDScoreObjects5.length = 0;
gdjs.New_32sceneCode.GDCoinObjects1.length = 0;
gdjs.New_32sceneCode.GDCoinObjects2.length = 0;
gdjs.New_32sceneCode.GDCoinObjects3.length = 0;
gdjs.New_32sceneCode.GDCoinObjects4.length = 0;
gdjs.New_32sceneCode.GDCoinObjects5.length = 0;
gdjs.New_32sceneCode.GDCoinIconObjects1.length = 0;
gdjs.New_32sceneCode.GDCoinIconObjects2.length = 0;
gdjs.New_32sceneCode.GDCoinIconObjects3.length = 0;
gdjs.New_32sceneCode.GDCoinIconObjects4.length = 0;
gdjs.New_32sceneCode.GDCoinIconObjects5.length = 0;
gdjs.New_32sceneCode.GDLeftButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDLeftButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDLeftButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDLeftButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDLeftButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDRightButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDRightButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDRightButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDRightButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDRightButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDJumpButtonObjects1.length = 0;
gdjs.New_32sceneCode.GDJumpButtonObjects2.length = 0;
gdjs.New_32sceneCode.GDJumpButtonObjects3.length = 0;
gdjs.New_32sceneCode.GDJumpButtonObjects4.length = 0;
gdjs.New_32sceneCode.GDJumpButtonObjects5.length = 0;
gdjs.New_32sceneCode.GDArrowButtonsBgObjects1.length = 0;
gdjs.New_32sceneCode.GDArrowButtonsBgObjects2.length = 0;
gdjs.New_32sceneCode.GDArrowButtonsBgObjects3.length = 0;
gdjs.New_32sceneCode.GDArrowButtonsBgObjects4.length = 0;
gdjs.New_32sceneCode.GDArrowButtonsBgObjects5.length = 0;


{

gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i].hide();
}
}}

}


{

gdjs.New_32sceneCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].setPosition((( gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[0].getPointX(""))-12,(( gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[0].getPointY("")));
}
}
}


{



}


{

gdjs.New_32sceneCode.GDPlayerObjects1.length = 0;

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "RShift");
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
{gdjs.New_32sceneCode.conditionTrue_1 = gdjs.New_32sceneCode.condition1IsTrue_0;
gdjs.New_32sceneCode.GDPlayerObjects1_1final.length = 0;gdjs.New_32sceneCode.condition0IsTrue_1.val = false;
gdjs.New_32sceneCode.condition1IsTrue_1.val = false;
{
gdjs.New_32sceneCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects2[i].getAnimation() == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_1.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects2[k] = gdjs.New_32sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects2.length = k;if( gdjs.New_32sceneCode.condition0IsTrue_1.val ) {
    gdjs.New_32sceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.New_32sceneCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.New_32sceneCode.GDPlayerObjects1_1final.indexOf(gdjs.New_32sceneCode.GDPlayerObjects2[j]) === -1 )
            gdjs.New_32sceneCode.GDPlayerObjects1_1final.push(gdjs.New_32sceneCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.New_32sceneCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerObjects2[i].getAnimation() == 2 ) {
        gdjs.New_32sceneCode.condition1IsTrue_1.val = true;
        gdjs.New_32sceneCode.GDPlayerObjects2[k] = gdjs.New_32sceneCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerObjects2.length = k;if( gdjs.New_32sceneCode.condition1IsTrue_1.val ) {
    gdjs.New_32sceneCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.New_32sceneCode.GDPlayerObjects2.length;j<jLen;++j) {
        if ( gdjs.New_32sceneCode.GDPlayerObjects1_1final.indexOf(gdjs.New_32sceneCode.GDPlayerObjects2[j]) === -1 )
            gdjs.New_32sceneCode.GDPlayerObjects1_1final.push(gdjs.New_32sceneCode.GDPlayerObjects2[j]);
    }
}
}
{
gdjs.New_32sceneCode.GDPlayerObjects1.createFrom(gdjs.New_32sceneCode.GDPlayerObjects1_1final);
}
}
}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}}

}


{

gdjs.New_32sceneCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[k] = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.New_32sceneCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[k] = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].setAnimation(1);
}
}}

}


{

gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[k] = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.New_32sceneCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.createFrom(gdjs.New_32sceneCode.GDPlayerHitBoxObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( !(gdjs.New_32sceneCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerHitBoxObjects2[k] = gdjs.New_32sceneCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects2[i].setAnimation(0);
}
}}

}


{

gdjs.New_32sceneCode.GDPlayerObjects2.createFrom(runtimeScene.getObjects("Player"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.createFrom(gdjs.New_32sceneCode.GDPlayerHitBoxObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerHitBoxObjects2[i].getBehavior("PlatformerObject").isMoving() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerHitBoxObjects2[k] = gdjs.New_32sceneCode.GDPlayerHitBoxObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects2[i].setAnimation(2);
}
}}

}

} //End of subevents
}

}


{

gdjs.New_32sceneCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].flipX(true);
}
}}

}


{

gdjs.New_32sceneCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerObjects1[i].flipX(false);
}
}}

}


{



}


{

gdjs.New_32sceneCode.GDPlayerObjects1.createFrom(runtimeScene.getObjects("Player"));

{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.New_32sceneCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDPlayerObjects1[0].getPointX("")), "", 0);
}
}


{



}


{

gdjs.New_32sceneCode.GDGoLeftObjects1.createFrom(runtimeScene.getObjects("GoLeft"));
gdjs.New_32sceneCode.GDGoRightObjects1.createFrom(runtimeScene.getObjects("GoRight"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDGoLeftObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDGoLeftObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDGoRightObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDGoRightObjects1[i].hide();
}
}}

}


{

gdjs.New_32sceneCode.GDGoLeftObjects1.createFrom(runtimeScene.getObjects("GoLeft"));
gdjs.New_32sceneCode.GDMovingPlatformObjects1.createFrom(runtimeScene.getObjects("MovingPlatform"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("GoLeft", gdjs.New_32sceneCode.GDGoLeftObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("MovingPlatform", gdjs.New_32sceneCode.GDMovingPlatformObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDMovingPlatformObjects1[i].addForce(-150, 0, 1);
}
}}

}


{

gdjs.New_32sceneCode.GDGoRightObjects1.createFrom(runtimeScene.getObjects("GoRight"));
gdjs.New_32sceneCode.GDMovingPlatformObjects1.createFrom(runtimeScene.getObjects("MovingPlatform"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("GoRight", gdjs.New_32sceneCode.GDGoRightObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("MovingPlatform", gdjs.New_32sceneCode.GDMovingPlatformObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDMovingPlatformObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDMovingPlatformObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDMovingPlatformObjects1[i].addForce(150, 0, 1);
}
}}

}


{



}


{



}


{

gdjs.New_32sceneCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects1[i].activateBehavior("PlatformerObject", false);
}
}}

}


{



}


{

gdjs.New_32sceneCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.New_32sceneCode.GDGoLeftObjects1.createFrom(runtimeScene.getObjects("GoLeft"));
gdjs.New_32sceneCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("GoLeft", gdjs.New_32sceneCode.GDGoLeftObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("SlimeWalk", gdjs.New_32sceneCode.GDSlimeWalkObjects1).addObjectsToEventsMap("Fly", gdjs.New_32sceneCode.GDFlyObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].setVariableNumber(gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].getVariables().get("GoingLeft"), 1);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects1[i].setVariableNumber(gdjs.New_32sceneCode.GDFlyObjects1[i].getVariables().get("GoingLeft"), 1);
}
}}

}


{

gdjs.New_32sceneCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.New_32sceneCode.GDGoRightObjects1.createFrom(runtimeScene.getObjects("GoRight"));
gdjs.New_32sceneCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("GoRight", gdjs.New_32sceneCode.GDGoRightObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("SlimeWalk", gdjs.New_32sceneCode.GDSlimeWalkObjects1).addObjectsToEventsMap("Fly", gdjs.New_32sceneCode.GDFlyObjects1).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].setVariableNumber(gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].getVariables().get("GoingLeft"), 0);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects1[i].setVariableNumber(gdjs.New_32sceneCode.GDFlyObjects1[i].getVariables().get("GoingLeft"), 0);
}
}}

}


{

gdjs.New_32sceneCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.New_32sceneCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].getAnimation() == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDSlimeWalkObjects1[k] = gdjs.New_32sceneCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDFlyObjects1[i].getAnimation() == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDFlyObjects1[k] = gdjs.New_32sceneCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDFlyObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.New_32sceneCode.GDFlyObjects2.createFrom(gdjs.New_32sceneCode.GDFlyObjects1);
gdjs.New_32sceneCode.GDSlimeWalkObjects2.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDSlimeWalkObjects2[k] = gdjs.New_32sceneCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDFlyObjects2[i].getVariableNumber(gdjs.New_32sceneCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 1 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDFlyObjects2[k] = gdjs.New_32sceneCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDFlyObjects2.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects2[i].addForce(-300, 0, 0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects2[i].flipX(false);
}
}}

}


{

gdjs.New_32sceneCode.GDFlyObjects2.createFrom(gdjs.New_32sceneCode.GDFlyObjects1);
gdjs.New_32sceneCode.GDSlimeWalkObjects2.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].getVariableNumber(gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDSlimeWalkObjects2[k] = gdjs.New_32sceneCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDFlyObjects2[i].getVariableNumber(gdjs.New_32sceneCode.GDFlyObjects2[i].getVariables().get("GoingLeft")) == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDFlyObjects2[k] = gdjs.New_32sceneCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDFlyObjects2.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects2[i].addForce(300, 0, 0);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects2[i].flipX(true);
}
}}

}


{



}


{

gdjs.New_32sceneCode.GDFlyObjects2.createFrom(gdjs.New_32sceneCode.GDFlyObjects1);
gdjs.New_32sceneCode.GDPlayerHitBoxObjects2.createFrom(runtimeScene.getObjects("PlayerHitBox"));
gdjs.New_32sceneCode.GDSlimeWalkObjects2.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("PlayerHitBox", gdjs.New_32sceneCode.GDPlayerHitBoxObjects2).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("SlimeWalk", gdjs.New_32sceneCode.GDSlimeWalkObjects2).addObjectsToEventsMap("Fly", gdjs.New_32sceneCode.GDFlyObjects2).getEventsObjectsMap(), false, runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {

{ //Subevents

{

gdjs.New_32sceneCode.GDFlyObjects3.createFrom(gdjs.New_32sceneCode.GDFlyObjects2);
gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.createFrom(gdjs.New_32sceneCode.GDPlayerHitBoxObjects2);
gdjs.New_32sceneCode.GDSlimeWalkObjects3.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects2);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[k] = gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects3[i].activateBehavior("PlatformerObject", true);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects3[i].activateBehavior("PlatformerObject", true);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects3[i].getBehavior("PlatformerObject").setGravity(1500);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects3[i].getBehavior("PlatformerObject").setGravity(1500);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[i].getBehavior("PlatformerObject").setCanJump();
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "jump.wav", false, 100, 1);
}
{ //Subevents

{

gdjs.New_32sceneCode.GDFlyObjects4.createFrom(gdjs.New_32sceneCode.GDFlyObjects3);
gdjs.New_32sceneCode.GDSlimeWalkObjects4.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects3);

gdjs.New_32sceneCode.forEachTotalCount5 = 0;
gdjs.New_32sceneCode.forEachObjects5.length = 0;
gdjs.New_32sceneCode.forEachCount0_5 = gdjs.New_32sceneCode.GDSlimeWalkObjects4.length;
gdjs.New_32sceneCode.forEachTotalCount5 += gdjs.New_32sceneCode.forEachCount0_5;
gdjs.New_32sceneCode.forEachObjects5.push.apply(gdjs.New_32sceneCode.forEachObjects5,gdjs.New_32sceneCode.GDSlimeWalkObjects4);
gdjs.New_32sceneCode.forEachCount1_5 = gdjs.New_32sceneCode.GDFlyObjects4.length;
gdjs.New_32sceneCode.forEachTotalCount5 += gdjs.New_32sceneCode.forEachCount1_5;
gdjs.New_32sceneCode.forEachObjects5.push.apply(gdjs.New_32sceneCode.forEachObjects5,gdjs.New_32sceneCode.GDFlyObjects4);
for(gdjs.New_32sceneCode.forEachIndex5 = 0;gdjs.New_32sceneCode.forEachIndex5 < gdjs.New_32sceneCode.forEachTotalCount5;++gdjs.New_32sceneCode.forEachIndex5) {
gdjs.New_32sceneCode.GDFlyObjects5.createFrom(gdjs.New_32sceneCode.GDFlyObjects4);
gdjs.New_32sceneCode.GDSlimeWalkObjects5.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects4);

gdjs.New_32sceneCode.GDSlimeWalkObjects5.length = 0;
gdjs.New_32sceneCode.GDFlyObjects5.length = 0;
if (gdjs.New_32sceneCode.forEachIndex5 < gdjs.New_32sceneCode.forEachCount0_5) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects5.push(gdjs.New_32sceneCode.forEachObjects5[gdjs.New_32sceneCode.forEachIndex5]);
}
else if (gdjs.New_32sceneCode.forEachIndex5 < gdjs.New_32sceneCode.forEachCount0_5+gdjs.New_32sceneCode.forEachCount1_5) {
    gdjs.New_32sceneCode.GDFlyObjects5.push(gdjs.New_32sceneCode.forEachObjects5[gdjs.New_32sceneCode.forEachIndex5]);
}
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(50);
}}
}

}

} //End of subevents
}

}


{

gdjs.New_32sceneCode.GDFlyObjects3.createFrom(gdjs.New_32sceneCode.GDFlyObjects2);
gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.createFrom(gdjs.New_32sceneCode.GDPlayerHitBoxObjects2);
gdjs.New_32sceneCode.GDSlimeWalkObjects3.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects2);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[i].getY() >= (( gdjs.New_32sceneCode.GDFlyObjects3.length === 0 ) ? (( gdjs.New_32sceneCode.GDSlimeWalkObjects3.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDSlimeWalkObjects3[0].getPointY("")) :gdjs.New_32sceneCode.GDFlyObjects3[0].getPointY(""))-(gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[i].getHeight())+(( gdjs.New_32sceneCode.GDFlyObjects3.length === 0 ) ? (( gdjs.New_32sceneCode.GDSlimeWalkObjects3.length === 0 ) ? 0 :gdjs.New_32sceneCode.GDSlimeWalkObjects3[0].getHeight()) :gdjs.New_32sceneCode.GDFlyObjects3[0].getHeight())/2 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[k] = gdjs.New_32sceneCode.GDPlayerHitBoxObjects3[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDPlayerHitBoxObjects3.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
}

}

} //End of subevents
}

}

} //End of subevents
}

}


{



}


{

gdjs.New_32sceneCode.GDFlyObjects1.createFrom(runtimeScene.getObjects("Fly"));
gdjs.New_32sceneCode.GDSlimeWalkObjects1.createFrom(runtimeScene.getObjects("SlimeWalk"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
gdjs.New_32sceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].getAnimation() == 1 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDSlimeWalkObjects1[k] = gdjs.New_32sceneCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDFlyObjects1[i].getAnimation() == 1 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDFlyObjects1[k] = gdjs.New_32sceneCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDFlyObjects1.length = k;}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.New_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDSlimeWalkObjects1[k] = gdjs.New_32sceneCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDFlyObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.New_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDFlyObjects1[k] = gdjs.New_32sceneCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDFlyObjects1.length = k;}if ( gdjs.New_32sceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length;i<l;++i) {
    if ( !(gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.New_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDSlimeWalkObjects1[k] = gdjs.New_32sceneCode.GDSlimeWalkObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDSlimeWalkObjects1.length = k;for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDFlyObjects1.length;i<l;++i) {
    if ( !(gdjs.New_32sceneCode.GDFlyObjects1[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.New_32sceneCode.condition2IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDFlyObjects1[k] = gdjs.New_32sceneCode.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDFlyObjects1.length = k;}}
}
if (gdjs.New_32sceneCode.condition2IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].activateBehavior("PlatformerObject", false);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects1[i].activateBehavior("PlatformerObject", false);
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].setOpacity(gdjs.New_32sceneCode.GDSlimeWalkObjects1[i].getOpacity() - (50*gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects1[i].setOpacity(gdjs.New_32sceneCode.GDFlyObjects1[i].getOpacity() - (50*gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}
{ //Subevents

{

gdjs.New_32sceneCode.GDFlyObjects2.createFrom(gdjs.New_32sceneCode.GDFlyObjects1);
gdjs.New_32sceneCode.GDSlimeWalkObjects2.createFrom(gdjs.New_32sceneCode.GDSlimeWalkObjects1);

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].getOpacity() == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDSlimeWalkObjects2[k] = gdjs.New_32sceneCode.GDSlimeWalkObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDSlimeWalkObjects2.length = k;for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDFlyObjects2.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDFlyObjects2[i].getOpacity() == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDFlyObjects2[k] = gdjs.New_32sceneCode.GDFlyObjects2[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDFlyObjects2.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDSlimeWalkObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDSlimeWalkObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.New_32sceneCode.GDFlyObjects2.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDFlyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}

} //End of subevents
}

}


{



}


{



}


{

gdjs.New_32sceneCode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
gdjs.New_32sceneCode.condition1IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(context.clearEventsObjectsMap().addObjectsToEventsMap("PlayerHitBox", gdjs.New_32sceneCode.GDPlayerHitBoxObjects1).getEventsObjectsMap(), context.clearEventsObjectsMap().addObjectsToEventsMap("Coin", gdjs.New_32sceneCode.GDCoinObjects1).getEventsObjectsMap(), false, runtimeScene);
}if ( gdjs.New_32sceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDCoinObjects1[i].getOpacity() == 255 ) {
        gdjs.New_32sceneCode.condition1IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDCoinObjects1[k] = gdjs.New_32sceneCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDCoinObjects1.length = k;}}
if (gdjs.New_32sceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCoinObjects1[i].setOpacity(254);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 100, 1);
}{runtimeScene.getVariables().getFromIndex(0).add(100);
}}

}


{

gdjs.New_32sceneCode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDCoinObjects1[i].getOpacity() < 255 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDCoinObjects1[k] = gdjs.New_32sceneCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDCoinObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCoinObjects1[i].setOpacity(gdjs.New_32sceneCode.GDCoinObjects1[i].getOpacity() - (255*gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.New_32sceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCoinObjects1[i].addForce(0, -30, 0);
}
}}

}


{

gdjs.New_32sceneCode.GDCoinObjects1.createFrom(runtimeScene.getObjects("Coin"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.New_32sceneCode.GDCoinObjects1.length;i<l;++i) {
    if ( gdjs.New_32sceneCode.GDCoinObjects1[i].getOpacity() == 0 ) {
        gdjs.New_32sceneCode.condition0IsTrue_0.val = true;
        gdjs.New_32sceneCode.GDCoinObjects1[k] = gdjs.New_32sceneCode.GDCoinObjects1[i];
        ++k;
    }
}
gdjs.New_32sceneCode.GDCoinObjects1.length = k;}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDCoinObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDCoinObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{



}


{

gdjs.New_32sceneCode.GDScoreObjects1.createFrom(runtimeScene.getObjects("Score"));

{for(var i = 0, len = gdjs.New_32sceneCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDScoreObjects1[i].setString("x "+gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}
}


{



}


{

gdjs.New_32sceneCode.GDArrowButtonsBgObjects1.createFrom(runtimeScene.getObjects("ArrowButtonsBg"));
gdjs.New_32sceneCode.GDJumpButtonObjects1.createFrom(runtimeScene.getObjects("JumpButton"));
gdjs.New_32sceneCode.GDLeftButtonObjects1.createFrom(runtimeScene.getObjects("LeftButton"));
gdjs.New_32sceneCode.GDRightButtonObjects1.createFrom(runtimeScene.getObjects("RightButton"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDLeftButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDLeftButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.New_32sceneCode.GDRightButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDRightButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.New_32sceneCode.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDJumpButtonObjects1[i].hide();
}
for(var i = 0, len = gdjs.New_32sceneCode.GDArrowButtonsBgObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDArrowButtonsBgObjects1[i].hide();
}
}}

}


{


gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}}

}


{

gdjs.New_32sceneCode.GDLeftButtonObjects1.createFrom(runtimeScene.getObjects("LeftButton"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("LeftButton", gdjs.New_32sceneCode.GDLeftButtonObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}}

}


{

gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));
gdjs.New_32sceneCode.GDRightButtonObjects1.createFrom(runtimeScene.getObjects("RightButton"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("RightButton", gdjs.New_32sceneCode.GDRightButtonObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}}

}


{

gdjs.New_32sceneCode.GDJumpButtonObjects1.createFrom(runtimeScene.getObjects("JumpButton"));
gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.createFrom(runtimeScene.getObjects("PlayerHitBox"));

gdjs.New_32sceneCode.condition0IsTrue_0.val = false;
{
gdjs.New_32sceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(context.clearEventsObjectsMap().addObjectsToEventsMap("JumpButton", gdjs.New_32sceneCode.GDJumpButtonObjects1).getEventsObjectsMap(), runtimeScene, true, false);
}if (gdjs.New_32sceneCode.condition0IsTrue_0.val) {
{for(var i = 0, len = gdjs.New_32sceneCode.GDPlayerHitBoxObjects1.length ;i < len;++i) {
    gdjs.New_32sceneCode.GDPlayerHitBoxObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}

return;
}
gdjs['New_32sceneCode']= gdjs.New_32sceneCode;
